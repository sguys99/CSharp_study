﻿//written by im.kim on '22.01.13
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace Tool
{
    public static class CSV
    {
        public static void SaveCSV(this string contents, string filePath, string[] columnsTitle)
        {
            ReaderWriterLockSlim loc = new();
            loc.EnterWriteLock();
            try
            {
                if (File.Exists(filePath))
                {
                    using var sw = File.AppendText(filePath);
                    sw.WriteLine(contents); //,으로 column구분
                }
                else
                {
                    if (!Directory.Exists(Path.GetDirectoryName(filePath))) Directory.CreateDirectory(Path.GetDirectoryName(filePath));
                    using var sw = File.CreateText(filePath);
                    sw.WriteLine(string.Join(',', columnsTitle));
                    sw.WriteLine(contents); //,으로 column구분
                }
            }
            catch (Exception e) { Debug.WriteLine($"Fail to Save CSV:{e}"); }
            loc.ExitWriteLock();
        }
        public static List<string[]> LoadCSV(this string filePath)
        {
            List<string[]> contents = new();
            if (File.Exists(filePath))
            {
                ReaderWriterLockSlim loc = new();
                loc.EnterWriteLock();
                try { contents.AddRange(from row in File.ReadAllLines(filePath, Encoding.UTF8) select row.Split(',')); }
                catch (Exception e) { Debug.WriteLine($"Fail to Load CSV:{e}"); }
                loc.ExitWriteLock();
            }
            return contents;
        }
    }
}