﻿//written by im.kim on '22.01.13
using System;
using System.Diagnostics;
using System.IO;
using System.Xml.Serialization;

namespace Tool
{
    public static class XML
    {
        public static void SaveXMLSerialize<T>(this T obj, string fileName)
        {
            if (!Directory.Exists(Path.GetDirectoryName(fileName))) Directory.CreateDirectory(Path.GetDirectoryName(fileName));
            using StreamWriter wr = new(fileName);
            XmlSerializer xs = new(typeof(T));
            xs.Serialize(wr, obj);
        }
        public static void LoadXMLSerialize<T>(ref T obj, string fileName)
        {
            try
            {
                using StreamReader reader = new(fileName);
                XmlSerializer xs = new(typeof(T));
                obj = (T)xs.Deserialize(reader);
            }
            catch (Exception e) { Debug.WriteLine($"Fail to Load XML:{e}"); obj.SaveXMLSerialize(fileName); }
        }
    }
}