﻿//written by im.kim on '22.01.13
using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Xml.Serialization;
using static Tool.C;

namespace Tool
{
    public static class Conversion
    {
        public static bool Bool(this object o) => Convert.ToBoolean(o);
        public static string Str(this object o) => o.ToString();
        public static bool[] BoolArray(this int i) { bool[] ba = new bool[INTBIT]; new BitArray(new int[] { i }).CopyTo(ba, 0); return ba; }
        public static int Int(this string s, NumberStyles ns = NumberStyles.Integer) => int.Parse(s, ns);
        public static int Int(this object o) => Convert.ToInt32(o);
        public static double Dbl(this string s) => double.Parse(s);
        public static T ToEnum<T>(this object value) => (T)Enum.Parse(typeof(T), value.ToString(), true);
        public static int EnumToInt<T>(this object value) => (int)Enum.Parse(typeof(T), value.ToString(), true);
        public static byte[] ToByteArray<T>(this T t)
        {
            if (typeof(T) == typeof(int[]))
            {
                int[] ia = (int[])Convert.ChangeType(t, typeof(int[]));
                byte[] ba = new byte[ia.Length * sizeof(int)];
                Buffer.BlockCopy(ia, 0, ba, 0, ba.Length);
                return ba;
            }
            if (typeof(T).IsLayoutSequential)
            {
                byte[] ba = new byte[Marshal.SizeOf(t)];
                IntPtr p = Marshal.AllocHGlobal(Marshal.SizeOf(t));
                Marshal.StructureToPtr(t, p, false);//byte array로 직렬화
                Marshal.Copy(p, ba, 0, Marshal.SizeOf(t));
                Marshal.FreeHGlobal(p);
                return ba;
            }
            return default;
        }
        public static T To<T>(this object o) => (T)Convert.ChangeType(o, typeof(T));
        public static T ToStructure<T>(this byte[] ba)
        {
            if (typeof(T).IsArray) return default;
            IntPtr p = Marshal.AllocHGlobal(ba.Length);
            Marshal.Copy(ba, 0, p, ba.Length);
            Marshal.PtrToStructure<T>(p);
            T t = Marshal.PtrToStructure<T>(p);
            Marshal.FreeHGlobal(p);
            return t;
        }
        public static int ToInt(this byte[] ba) => BitConverter.ToInt32(ba.Take(4).ToArray(), 0);
        public static int[] ToIntArray(this byte[] ba, int size)
        {
            int[] ia = new int[size];
            Buffer.BlockCopy(ba, 0, ia, 0, size * 4);
            return ia;
        }
        public static T Clone<T>(this T obj)
        {
            using MemoryStream s = new();
            XmlSerializer serializer = new(obj.GetType());
            serializer.Serialize(s, obj);
            s.Seek(0, SeekOrigin.Begin);
            return (T)serializer.Deserialize(s);
        }
        public static Color GetPixelColor(this ImageSource source, double x, double y)
        {
            Color color;
            BitmapSource bitmap = (BitmapSource)source;
            var bytesPerPixel = (bitmap.Format.BitsPerPixel + 7) / 8;
            var bytes = new byte[bytesPerPixel];
            var rect = new Int32Rect((int)x, (int)y, 1, 1);
            if (x >= bitmap.Width || x < 0 || y >= bitmap.Height || y < 0) return Colors.Black;
            bitmap.CopyPixels(rect, bytes, bytesPerPixel, 0);
            if (bitmap.Format == PixelFormats.Gray8) color = Color.FromRgb(bytes[0], bytes[0], bytes[0]);
            else if (bitmap.Format == PixelFormats.Bgra32) color = Color.FromArgb(bytes[3], bytes[2], bytes[1], bytes[0]);
            else if (bitmap.Format == PixelFormats.Bgr32) color = Color.FromRgb(bytes[2], bytes[1], bytes[0]);
            else color = Colors.Black;
            return color;
        }
    }
}