﻿using System;
using Tool;

namespace DataLibrary.LogType
{
    public class LogItem
    {
        public DateTime Date { get; private set; }
        public string Category { get; private set; }
        public string Item { get; private set; }
        public string Detail { get; private set; }
        public LogItem(DateTime d, string[] str)    //File용
        {
            var t = str[0].Split(' ');//시분초 밀리초
            if (t.Length != 2) return;
            var m = Array.ConvertAll(t[0].Split(':'), int.Parse);//시분초
            Date = new(d.Year, d.Month, d.Day, m[0], m[1], m[2], t[1].Int());
            Category = str[1];
            Item = str[2];
            Detail = str[3];
        }
        public LogItem(string category, string item = "", string detail = "") { Date = DateTime.Now; Category = category; Item = item; Detail = detail; }
        public LogItem(DateTime date, string category, string item = "", string detail = "") { Date = date; Category = category; Item = item; Detail = detail; }
    }
}