﻿using System;
using System.Collections.Generic;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.Structure
{
    public class Share
    {
        readonly MemoryMappedFile sourceWriteMemory;  //메모리에만 남는 shared memory 구현. 쓰는 쪽 객체가 살아있어야만, 읽는 쪽에서 읽기 가능
        MemoryMappedFile destinationReadMemory;  //메모리에만 남는 shared memory 구현. 쓰는 쪽 객체가 살아있어야만, 읽는 쪽에서 읽기 가능
        public string SourceName { get; private set; }
        public string DestinationName { get; private set; }
        public string WriteName { get { return SourceName + "_To_" + DestinationName; } }
        public string ReadName { get { return DestinationName + "_To_" + SourceName; } }
        public int ByteSize { get; private set; }
        public Share(string sourceName, string destinationName, int byteSize = 10000)
        {
            SourceName = sourceName;
            DestinationName = destinationName;
            ByteSize = byteSize;
            if (ByteSize <= 0) return;
            //sourceWriteMemory = MemoryMappedFile.CreateNew(WriteName, Capacity);
            sourceWriteMemory = MemoryMappedFile.CreateOrOpen(WriteName, ByteSize);
        }
        public void Write(byte[] ba) { if (ba.Length != 0) sourceWriteMemory?.CreateViewStream().Write(ba, 0, ba.Length); }
        public byte[] Read()
        {
            try
            {
                //using MemoryMappedViewStream stream = MemoryMappedFile.OpenExisting(ReadName)?.CreateViewStream();
                byte[] ba = new byte[ByteSize];
                MemoryMappedFile.OpenExisting(ReadName)?.CreateViewStream().Read(ba, 0, ByteSize);
                return ba;
            }
            catch { destinationReadMemory = MemoryMappedFile.CreateOrOpen(ReadName, ByteSize); return default; }
        }
    }
}