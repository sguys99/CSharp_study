﻿using System;

namespace DataLibrary.LogType
{
    public class Error
    {
        public string Name { get; set; }
        public int ErrorCode { get; set; }
        public string Message { get; set; }
        public DateTime Time { get; set; }
        public Error(string name, int errorCode, string message)
        {
            Name = name;
            ErrorCode = errorCode;
            Message = message;
            Time = DateTime.Now;
        }
    }
}
