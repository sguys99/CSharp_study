﻿using DataLibrary.EnumDefine;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;

namespace DataLibrary.Structure
{
    public class Serial : Memory
    {
        public event SendVariableEventHandler<string> OccurAlarm;
        public event SendVariableEventHandler<byte[]> Transfer;
        public static readonly char STX = (char)0x02;   //Start Text [본문 시작, 헤더 종료]
        public static readonly char ETX = (char)0x03;   //End Text [본문 종료]
        public static readonly char EOT = (char)0x04;   //End of Transmission [전송 동료, 데이터 링크 초기화]
        public static readonly char ENQ = (char)0x05;   //Enquiry [응답 요구]
        public static readonly char ACK = (char)0x06;   //Acknowledge [긍정 응답]
        public static readonly char LF = (char)0x0A;    //Line Feed [개행]
        public static readonly char CR = (char)0x0D;    //Carriage Return [복귀]
        public static readonly char NAK = (char)0x15;   //Not Acknowledge [부정 응답]
        protected SerialPort serial;
        protected ReaderWriterLockSlim loc = new();
        protected List<byte> list = new();
        public Serial(string deviceName, bool isUI, COMPORT comPort, BAUDRATE baudrate, DataBits databit = DataBits.D8, Parity parity = Parity.None, StopBits stopBits = StopBits.One) : base(deviceName, isUI)
        {
            Initialize(comPort, baudrate, databit, parity, stopBits);
        }
        public void Initialize(COMPORT comPort, BAUDRATE baudrate, DataBits databit = DataBits.D8, Parity parity = Parity.None, StopBits stopBits = StopBits.One)
        {
            serial = new SerialPort { PortName = comPort.ToString(), BaudRate = (int)baudrate, DataBits = (int)databit, Parity = parity, StopBits = stopBits, DtrEnable = true, RtsEnable = true };
            serial.DataReceived += SerialPort_DataReceived;
            if (serial.IsOpen) { serial.Close(); }
        }
        public override void Dispose()
        {
            base.Dispose();
            if (GetOpen()) Close();
        }
        public override void Open()
        {
            if (isUI) base.Open();
            else
            {
                if (!SerialPort.GetPortNames().Contains(serial.PortName))
                {
                    OccurAlarm?.Invoke("Can't Open Serial");
                    return;
                }
                serial.Open();
                sts.Set(MEMORY_STS.OPENED, true);
            }
        }
        public override void Close()
        {
            if (isUI) base.Close();
            else
            {
                serial.Close();
                sts.Set(MEMORY_STS.OPENED, false);
            }
        }
        public void Write(string s)
        {
            if (!serial.IsOpen) return;
            serial.Write(s);
            log.Info($"Send {s.Replace("\n", "")}", false);
        }
        public void Write(params byte[] b)
        {
            if (!serial.IsOpen) return;
            serial.Write(b, 0, b.Length);
            log.Info($"Send {Encoding.ASCII.GetString(b).Replace("\n", "")}", false);
        }
        public void Write(params char[] c)
        {
            if (!serial.IsOpen) return;
            serial.Write(c, 0, c.Length);
            log.Info($"Send {new string(c).Replace("\n", "")}", false);
        }
        protected virtual void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int readSize = serial.BytesToRead;
            if (readSize != 0)
            {
                byte[] buffer = new byte[readSize];
                serial.Read(buffer, 0, readSize);
                //log.Info($"Raw Receive {Encoding.ASCII.GetString(buffer).Replace("\n", "")}");
                loc.EnterWriteLock();
                if (list.Count > 10000) list.Clear();
                list.AddRange(buffer);
                loc.ExitWriteLock();
                Transfer?.Invoke(buffer);
            }
        }
        public static char GetBCC(string str)
        {   //RKC Heater Controller(RS485)의 체크섬 용도임.(Katrina, Marcia, Testbed에 장착되어 있음)
            char bcc = str[0];
            for (int i = 1; i < str.Length; i++) bcc ^= str[i];
            return bcc;
        }

        //고산테크 MODBUS RTU MPC는 Address 범위 1~99, 115200 baud rate 사용함
        //485 Non Echo 모드 사용함
        //F3(읽기코드)에서 reg=50은 val=1:run, val=0:stop(현재 MPC 음압 Run)
        //F3(읽기코드)에서 reg=51은 val=3000Pa(현재 음압값)
        //F6(쓰기코드)에서 reg=1은 val=1:run, val=0:stop(목표 런)
        //F6(쓰기코드)에서 reg=2은 val=3000Pa(목표 음압값)
        public void SetModbus(int addr, MOD_FN fn, ushort reg, ushort val)
        {   //고산테크 MPC RS485 MODBUS-RTU용으로 작성함. 변경 가능
            //Modbus Frame 8bytes{addr, fn, Data(2bytes Big-Endian){sts Hi, reg Low, reg Hi, val Low}, CRC16(Little Endian 2bytes)}
            List<byte> frame = new() { (byte)addr, (byte)fn };
            frame.AddRange(BitConverter.GetBytes(reg).Reverse());//Endian Little→Big
            frame.AddRange(BitConverter.GetBytes(val).Reverse());//Endian Little→Big
            frame.AddRange(GetCRC16(frame.ToArray()));//얘만 Little Endian임. 요상함.
            Write(frame.ToArray());
        }
        public bool GetModbus(byte[] bytes, out int addr, out MOD_FN fn, out ushort reg, out ushort val)
        {   //고산테크 MPC RS485 MODBUS-RTU용으로 작성함. 변경 가능
            addr = 0; fn = MOD_FN.F1; reg = 0; val = 0; //초기값 할당
            if (bytes.Length != 8) return false;
            if (!GetCRC16(bytes[..6]).SequenceEqual(bytes[^2..])) return false; //체크섬이 맞지 않음
            addr = bytes[0];
            fn = (MOD_FN)bytes[1];
            reg = BitConverter.ToUInt16(bytes[2..4].Reverse().ToArray());//Endian Big→Little
            val = BitConverter.ToUInt16(bytes[4..6].Reverse().ToArray());//Endian Big→Little
            return true;    //정상적으로 Parsing함
        }
        public static byte[] GetCRC16(params byte[] bytes)
        {
            ushort crc = 0xFFFF, p = 0xA001;   //CRC-16-IBM Reversed
            var tbl = new ushort[256];
            for (ushort i = 0; i < tbl.Length; ++i)   //Calculate CRC16 Table
            {
                ushort v = 0, t = i;
                for (int j = 0; j < 8; ++j)
                {
                    if (((v ^ t) & 1) == 0) v >>= 1;
                    else v = (ushort)(v >> 1 ^ p);
                    t >>= 1;
                }
                tbl[i] = v;
            }
            foreach (var v in bytes) crc = (ushort)(crc >> 8 ^ tbl[(byte)(v ^ crc)]);
            return BitConverter.GetBytes(crc);    //Calculate CRC16 and return
        }
    }
}