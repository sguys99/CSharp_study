﻿using DataLibrary.EnumDefine;
using DataLibrary.UserType;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.Structure.IO.Motion
{
    [Serializable]
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct Motor
    {
        public byte Index { get; private set; }
        public UNIT Unit;
        public Word Control;
        long aPos, rPos;    //Memory에 써주는 데이터 기준[0.1um]
        int gear, encoder, uiMag, mMag, vel, acc, dec, jerk, rms;
        //접미어 U: UI[mm], M: Motor[mm or um]
        public int Gear { get { if (gear < 1) gear = 1; return gear; } set { if (value > 0) gear = value; } }
        public int Encoder { get { if (encoder < 1) encoder = 1; return encoder; } set { if (value > 0) encoder = value; } }
        public double Ratio => (double)Gear / Encoder;   //mm단위, 1회전 4194304 count일 때 10mm 이동 볼스크류에서는 CountX10/4194304 = 10mm 로 환산됨
        public int UIMag { get { if (uiMag < 1) uiMag = 1; return uiMag; } set { if (value > 0) uiMag = value; } }
        public int MMag { get { if (mMag < 1) mMag = 1; return mMag; } set { if (value > 0) mMag = value; } }
        public double APosU { get => aPos * Ratio / UIMag; set => aPos = (long)(value / Ratio * UIMag); }
        public double APosM { get => aPos * Ratio / UIMag * MMag; set => aPos = (long)(value / Ratio * UIMag / MMag); }
        public double RPosU { get => rPos * Ratio / UIMag; set => rPos = (long)(value / Ratio * UIMag); }
        public double RPosM { get => rPos * Ratio / UIMag * MMag; set => rPos = (long)(value / Ratio * UIMag / MMag); }
        public double VelU { get => vel * Ratio / UIMag; set => vel = (int)(value / Ratio * UIMag); }
        public double VelM { get => vel * Ratio / UIMag * MMag; set => vel = (int)(value / Ratio * UIMag / MMag); }
        public double AccU { get => acc * Ratio / UIMag; set => acc = (int)(value / Ratio * UIMag); }
        public double AccM { get => acc * Ratio / UIMag * MMag; set => acc = (int)(value / Ratio * UIMag / MMag); }
        public double DecU { get => dec * Ratio / UIMag; set => dec = (int)(value / Ratio * UIMag); }
        public double DecM { get => dec * Ratio / UIMag * MMag; set => dec = (int)(value / Ratio * UIMag / MMag); }
        public double JerkU { get => jerk * Ratio / UIMag; set => jerk = (int)(value / Ratio * UIMag); }
        public double JerkM { get => jerk * Ratio / UIMag * MMag; set => jerk = (int)(value / Ratio * UIMag / MMag); }
        public double RMS { get { return (double)rms / UIMag; } set { rms = (int)(value * UIMag); } }
        public int AlarmCode;
        public static Motor[] Create(int count, int uiMag = 10000, int mMag = 1, int encoder = 1, int gear = 1)
        {
            var motor = new Motor[count];
            for (int i = 0; i < count; i++) { motor[i].Index = (byte)i; motor[i].Control = 0; motor[i].Gear = gear; motor[i].Encoder = encoder; motor[i].UIMag = uiMag; motor[i].MMag = mMag; }
            return motor;
        }
    }
}