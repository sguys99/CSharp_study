﻿using DataLibrary.EnumDefine;
using DataLibrary.UserType;
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Tool;

namespace DataLibrary.Structure.Vision
{
    public class Vision : IConnectable
    {//UI 입장에서 작성함
        public virtual event SendVariableEventHandler<byte[]> SendImage;
        public byte[] RawImage;
        public string SourceName { get; protected set; }
        public string DestinationName { get; protected set; }
        public CameraAssembly camAssy = new();
        protected Share share, shareCamAssy, shareImage;
        protected Word cmd, sts;
        public bool IsAlive;
        protected bool isRiseHeart;
        protected int heartCnt;
        protected Stopwatch heartSW = new();
        protected string camAssyName = "_CameraAssembly", imageName = "_Image";
        protected Task task;
        public Vision() { }
        public Vision(string sourceName, string destinationName) : this()
        {
            SourceName = sourceName;
            DestinationName = destinationName;
            cmd = 0; sts = 0;
            DeclareShareMemory();
            Initialize();
        }
        public void TestTick()
        {
            byte[] ba = new byte[20];
            SendImage?.Invoke(ba);
        }
        protected virtual void DeclareShareMemory()
        {
            shareCamAssy = new Share(SourceName, DestinationName + camAssyName, Marshal.SizeOf(typeof(CameraAssembly)));
            shareImage = new Share(SourceName, DestinationName + imageName, 2448 * 2048);
        }
        protected void Initialize()
        {
            share = new Share(SourceName, DestinationName, Marshal.SizeOf(typeof(Word)));
            task = new Task(Repeat);
            task.Start();
        }
        void Repeat()
        {
            heartSW.Restart();
            Stopwatch sw = new();
            while (true)
            {
                try
                {
                    sw.Restart();
                    HandShake();
                    Grab();
                    //HandShakeIO();
                    //HandShakeMotor();
                    //Process();
                    //Debug.WriteLine("Vision Repeat Tick:{0}", sw.ElapsedTicks);
                }
                catch (Exception e) { Debug.WriteLine($"Vision Repeat: {e}"); }
            }
        }
        protected virtual void HandShake()
        {
            if ((DateTime.Now.Millisecond % 100) < 50) cmd.Set(VISION_CMD.HEART, true);
            else cmd.Set(VISION_CMD.HEART, false);
            share.Write(cmd.ToByteArray());
            if (share.Read() is var r and not null)
            {
                if ((r[0] & 1) == 1 && !isRiseHeart)
                {
                    isRiseHeart = true;
                    heartCnt++;
                    heartSW.Restart();
                }
                if ((r[0] & 1) == 0) isRiseHeart = false;
                if (heartCnt >= 2)  //Heart Beat의 Rising이 3회 이상 감지된 경우
                {
                    heartCnt = 0;
                    IsAlive = true;
                    cmd = 0;
                    if (sts.Get(VISION_STS.OPENED))
                    {
                        cmd.Set(VISION_CMD.OPEN, true);
                        cmd.Set(VISION_CMD.CLOSE, false);
                    }
                    else
                    {
                        cmd.Set(VISION_CMD.OPEN, false);
                        cmd.Set(VISION_CMD.CLOSE, true);
                    }
                    if (sts.Get(VISION_STS.PLAYED))
                    {
                        cmd.Set(VISION_CMD.PLAY, true);
                        cmd.Set(VISION_CMD.STOP, false);
                    }
                    else
                    {
                        cmd.Set(VISION_CMD.PLAY, false);
                        cmd.Set(VISION_CMD.STOP, true);
                    }
                    if (shareCamAssy.Read() is var rc and not null) camAssy = rc.ToStructure<CameraAssembly>();
                }
                if (heartSW.ElapsedMilliseconds > 1000)
                {
                    //Debug.WriteLine("Vision Alive Timeout: {0}", heartSW.ElapsedMilliseconds);
                    IsAlive = false;
                    cmd = 0;
                    heartSW.Restart();
                }
                sts = r.ToInt();
            }
            else IsAlive = false;
        }
        protected virtual void Grab()
        {
            if (IsAlive)
            {
                if (sts.Get(VISION_STS.SND_IMG) && !cmd.Get(VISION_CMD.RCV_IMG))
                {
                    if (shareImage.Read() is var ri and not null)
                    {
                        RawImage = ri;
                        SendImage?.Invoke(ri);
                        cmd.Set(VISION_CMD.RCV_IMG, true);
                    }
                }
                if (!sts.Get(VISION_STS.SND_IMG)) cmd.Set(VISION_CMD.RCV_IMG, false);
            }
        }
        public virtual void Dispose() { }
        public virtual void Open()
        {
            cmd.Set(VISION_CMD.OPEN, true);
            cmd.Set(VISION_CMD.CLOSE, false);
        }
        public virtual void Close()
        {
            cmd.Set(VISION_CMD.OPEN, false);
            cmd.Set(VISION_CMD.CLOSE, true);
        }
        public bool GetOpen() => sts.Get(MEMORY_STS.OPENED);
        public virtual void Play()
        {
            cmd.Set(VISION_CMD.PLAY, true);
            cmd.Set(VISION_CMD.STOP, false);
        }
        public virtual void Stop()
        {
            cmd.Set(VISION_CMD.PLAY, false);
            cmd.Set(VISION_CMD.STOP, true);
        }
    }
}
