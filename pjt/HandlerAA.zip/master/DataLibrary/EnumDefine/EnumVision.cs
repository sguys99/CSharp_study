﻿namespace DataLibrary.EnumDefine
{
    public enum VISION_CMD { HEART, OPEN, CLOSE, PLAY, STOP, RCV_IMG }
    public enum VISION_STS { HEART, OPENED, PLAYED, SND_IMG }
}
