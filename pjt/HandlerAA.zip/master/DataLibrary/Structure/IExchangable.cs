﻿using System.Collections.Generic;

namespace DataLibrary.Structure
{
    public interface IExchangable
    {
        event SendVariableEventHandler<string> OccurAlarm;
        bool GetDI(int i);
        bool GetDO(int inidex);
        int GetAI(int i);
        int GetAO(int i);
        List<bool> GetDI();
        List<bool> GetDO();
        List<int> GetAI();
        List<int> GetAO();
        void SetDO(int i, bool v);
        void SetAO(int i, int v);
    }
}