﻿using DataLibrary.EnumDefine;
using DataLibrary.LogType;
using DataLibrary.UserType;
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Tool;

namespace DataLibrary.Structure
{
    public class Memory : IConnectable
    {
        public string SourceName { get; protected set; }
        public string DestinationName { get; protected set; }
        public bool IsAlive;
        protected readonly bool isUI;
        protected Word cmd, sts;
        protected bool isHigh, isDispose;
        protected int heartCount;
        protected Share share;
        protected Stopwatch heartSW = new();
        protected Log log;
        /// <summary>
        /// 기본이 되는 Memory Class. Ram 상의 공간을 이용하여 다른 프로그램과 Byte Array를 Share함.
        /// </summary>
        /// <param name="deviceName">Device이름 입력. 예: "ACS"</param>
        /// <param name="isUI">UI 여부 기입</param>
        public Memory(string deviceName, bool isUI = true)
        {
            this.isUI = isUI;
            cmd = 0; sts = 0;
            SourceName = isUI ? "UI" : deviceName;
            DestinationName = isUI ? deviceName : "UI";
            share = new(SourceName, DestinationName, C.INTBYTE);
            log = new(SourceName + "_To_" + DestinationName, "Shared_Memory");
            new Task(Repeat).Start();
            log.Info("Start");
        }
        public virtual void Open() => cmd.SetOnly(MEMORY_CMD.OPEN);
        public virtual void Close() => cmd.SetOnly(MEMORY_CMD.CLOSE);
        public bool GetOpen() => sts.Get(MEMORY_STS.OPENED);
        public virtual void Dispose() => isDispose = true;  //Terminate iteration
        void Repeat()
        {
            while (!isDispose)
            {
                try
                {
                    HandShakeMemory();
                    HandShakeEtc();
                    Process();
                    Thread.Sleep(1);
                }
                catch (Exception e) { log.Error($"Repeat Exception: {e}"); }
            }
        }
        void HandShakeMemory()
        {
            bool heart; //Heart Beat
            if ((DateTime.Now.Millisecond % 100) < 50) heart = true;
            else heart = false;
            if (isUI) share.Write(cmd.Set(MEMORY_CMD.HEART, heart).ToByteArray());
            else share.Write(sts.Set(MEMORY_STS.HEART, heart).ToByteArray());
            if (share.Read() is var r and not null)
            {
                if ((r[0] & 1) == 1 && !isHigh)
                {
                    isHigh = true;
                    heartCount++;
                    heartSW.Restart();
                }
                if ((r[0] & 1) == 0) isHigh = false;
                if (heartCount >= 2)  //Detect Heart Count 2
                {
                    heartCount = 0;
                    if (!IsAlive)
                    {
                        log.Info("Alive Handshake Memory");
                        IsAlive = true;
                    }
                    if (isUI) { if (!cmd.Get(MEMORY_CMD.READ_FIRST) && sts.Get(MEMORY_STS.READY_TO_READ)) cmd.Set(MEMORY_CMD.READ_FIRST, ReadFirst()); }
                    else { if (!sts.Get(MEMORY_STS.READY_TO_READ)) sts.Set(MEMORY_STS.READY_TO_READ, ReadFirst()); }
                    if (isUI) sts = r.ToInt();
                    else cmd = r.ToInt();
                }
                if (heartSW.ElapsedMilliseconds > 1000)
                {
                    log.Info("Dead Handshake Memory");
                    IsAlive = false;
                    if (isUI) cmd.Set(MEMORY_CMD.READ_FIRST, false);
                    else sts.Set(MEMORY_STS.READY_TO_READ, false);
                    heartSW.Restart();
                }

            }
            else IsAlive = false;
        }
        protected virtual bool ReadFirst() => true; //Read first when it open
        protected virtual void HandShakeEtc() { }
        protected virtual void Process() { }
    }
}