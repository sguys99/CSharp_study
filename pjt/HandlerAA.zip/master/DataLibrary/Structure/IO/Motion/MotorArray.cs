﻿using System;
using System.Runtime.InteropServices;
using Tool;

namespace DataLibrary.Structure.IO.Motion
{
    [Serializable]
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct MotorArray
    {
        [MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.Struct, SizeConst = C.AXES_COUNT)]
        public Motor[] MotorList;
        public static MotorArray Create(int count, int uiMag = 10000, int mMag = 1, int encoder = 1, int gear = 1) => new() { MotorList = Motor.Create(count, uiMag, mMag, encoder, gear) };
    }
}