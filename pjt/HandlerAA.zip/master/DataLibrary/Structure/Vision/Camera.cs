﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace DataLibrary.Structure.Vision
{
    [Serializable]
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct Camera
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 100)]
        public byte[] Name;
        public string SerialNumber;
        public int PixelWidth;
        public int PixelHeight;
        public double SensorWidth;
        public double SensorHeight;
        [MarshalAs(UnmanagedType.I1)]
        public bool IsColor;
        public static Camera Create(string name = "MV-CA050-10GM", string serialNumber = "02E28510182", int pixelWidth = 2448, int pixelHeight = 2048, double sensorWidth = 3.45, double sensorHeight = 3.45, bool isColor = false)
        {
            //MV-CA060-11GM 3072X2048 2.4um
            Camera camera = new();
            camera.Name = new byte[100];
            byte[] ba = Encoding.GetEncoding("UTF-8").GetBytes(name);
            Array.Copy(ba, camera.Name, ba.Length);
            camera.PixelWidth = pixelWidth;
            camera.PixelHeight = pixelHeight;
            camera.SensorWidth = sensorWidth;
            camera.SensorHeight = sensorHeight;
            camera.IsColor = isColor;
            camera.SerialNumber = serialNumber;
            return camera;
        }
    }
}