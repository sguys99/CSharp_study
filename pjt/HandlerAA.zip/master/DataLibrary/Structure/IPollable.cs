﻿namespace DataLibrary.Structure
{
    public interface IPollable
    {
        int Stage { get; set; }
        bool IsRunAutoFirst { get; set; }
        void Polling(bool IsDispose = false);
    }
}
