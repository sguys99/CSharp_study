﻿using DataLibrary.EnumDefine;
using System;
using System.Globalization;
using System.Runtime.InteropServices;
using Tool;

namespace DataLibrary.UserType
{
    /// <summary>
    /// Integer Customized
    /// B: Get Bit, S: Set Bit, T: Toggle Bit
    /// </summary>
    [Serializable]
    [StructLayout(LayoutKind.Sequential, Pack = 1)] //x64, x86 상관없이 직렬화 하기 위한 용도임
    public class Word : CustomType<Word, int>
    {
        private Word(int v) : base(v) => _v = v;
        public static implicit operator Word(int v) { return new Word(v); }
        public static implicit operator int(Word w) { return w._v; }
        public bool Get<T>(T t)
        {
            int i;
            if (typeof(T).IsEnum || typeof(T) == typeof(int)) i = Convert.ToInt32(t);
            else if (typeof(T) == typeof(string)) i = t.ToString().Int(NumberStyles.HexNumber);
            else return false;
            return (_v & 1 << i).Bool();
        }
        //public bool Get(int i) { return (_v & 1 << i).B(); }
        //public bool Get(string h) { return (_v & 1 << h.I(NumberStyles.HexNumber)).B(); }
        public bool[] Get() => _v.BoolArray();
        public int Set<T>(T t, bool v)
        {
            int i;
            if (typeof(T).IsEnum || typeof(T) == typeof(int)) i = Convert.ToInt32(t);
            else if (typeof(T) == typeof(string)) i = t.ToString().Int(NumberStyles.HexNumber);
            else return 0;
            if (v) _v |= 1 << i;
            else _v &= ~(1 << i);
            base._v = _v;
            return _v;
        }
        public void SetOnly<T>(T t)
        {
            int i;
            if (typeof(T).IsEnum || typeof(T) == typeof(int)) i = Convert.ToInt32(t);
            else if (typeof(T) == typeof(string)) i = t.ToString().Int(NumberStyles.HexNumber);
            else return;
            _v = 1 << i;
        }
        //public void Set(eMCMD c, bool v) { if (v) _v |= 1 << (int)c; else _v &= ~(1 << (int)c); }
        //public void Set(int i, bool v) { if (v) _v |= 1 << i; else _v &= ~(1 << i); }
        //public void Set(string h, bool v) { int i = h.I(NumberStyles.HexNumber); if (v) _v |= 1 << i; else _v &= ~(1 << i); }
        //public void SetOnly(eMCMD c) => _v = 1 << (int)c;
        public void Clear() => _v = 0;
        public void Toggle(MOTOR_CMD c) { Set(c, !Get(c)); }
        public void Toggle(int i) => Set(i, !Get(i));
        public void Toggle(string h) { int i = h.Int(NumberStyles.HexNumber); Set(i, !Get(i)); }
        public static Word[] Create(int count)
        {
            var word = new Word[count];
            for (int i = 0; i < count; i++) word[i] = 0;
            return word;
        }
        public static Word GetI(int value) => value;
        public static void Set(ref int value, int subIndex, bool setValue)
        {
            Word w = (Word)value;
            w.Set(subIndex, setValue);
            value = w;
        }
    }
}
