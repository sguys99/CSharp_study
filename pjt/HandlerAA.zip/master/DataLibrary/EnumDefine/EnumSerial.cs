﻿namespace DataLibrary.EnumDefine
{
    public enum COMPORT { COM1, COM2, COM3, COM4, COM5, COM6, COM7, COM8, COM9, COM10, COM11, COM12, COM13, COM14, COM15, COM16, COM17, COM18, COM19, COM20 }
    public enum BAUDRATE { B2400 = 2400, B4800 = 4800, B9600 = 9600, B19200 = 19200, B38400 = 38400, B115200 = 115200 }
    public enum DataBits { D7 = 7, D8 = 8 }
    public enum MOD_FN
    {
        F1 = 1,//read coil
        F2 = 2,//read discrete inputs
        F3 = 3,//read holding registers
        F4 = 4,//read input registers
        F5 = 5,//write single coil
        F6 = 6,//write single register
    }
}
