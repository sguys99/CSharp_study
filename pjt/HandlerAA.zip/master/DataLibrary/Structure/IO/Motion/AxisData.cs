﻿using System;

namespace DataLibrary.Structure.IO.Motion
{
    [Serializable]
    public class AxisData
    {
        public int Index;
        public string Name = "Empty";
        public double AbsPos, RelPos, Vel = 1, Acc = 10, Dec = 10, Jerk = 100, Jog1 = 0.01, Jog2 = 0.1, Jog3 = 1, Jog4 = 10, Jog5 = 50;
    }
}
