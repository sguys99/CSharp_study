﻿using DataLibrary.EnumDefine;
using DataLibrary.UserType;
using System.Runtime.InteropServices;
using Tool;

namespace DataLibrary.Structure.IO.Motion
{
    public class Motion : IO, IMovable
    {
        public override event SendVariableEventHandler<string> OccurAlarm;
        protected MotorArray MotorCommand, MotorState;
        protected Share shareMotor;
        protected string motorName = "_M";
        /// <summary>
        /// Memory, IO Class 상속. IMovable 구현
        /// </summary>
        /// <param name="deviceName">Device이름 입력. 예: "ACS"</param>
        /// <param name="isUI">UI 여부 기입</param>
        /// <param name="diSize">Int Size</param>
        /// <param name="doSize">Int Size</param>
        /// <param name="aiSize">Int Size</param>
        /// <param name="aoSize">Int Size</param>
        public Motion(string deviceName, bool isUI = true, int diSize = 2, int doSize = 2, int aiSize = 2, int aoSize = 2) : base(deviceName, isUI, diSize, doSize, aiSize, aoSize)
        {
            MotorCommand = MotorArray.Create(C.AXES_COUNT, C.SHARED_MEMORY_POINT_PLACE, C.ACS_POINT_PLACE);
            MotorState = MotorArray.Create(C.AXES_COUNT, C.SHARED_MEMORY_POINT_PLACE, C.ACS_POINT_PLACE);
            if (isUI) shareMotor = new Share(SourceName, DestinationName + motorName, Marshal.SizeOf(typeof(Motor)) * C.AXES_COUNT);
            else shareMotor = new Share(SourceName + motorName, DestinationName, Marshal.SizeOf(typeof(Motor)) * C.AXES_COUNT);
        }
        protected override bool ReadFirst()
        {
            base.ReadFirst();
            if (shareMotor.Read() is var rm and not null)
            {
                MotorCommand = rm.ToStructure<MotorArray>();
                for (int i = 0; i < C.AXES_COUNT; i++) MotorCommand.MotorList[i].Control = 0;//&= 0b11;   //Enable, Home만 Masking해서 사용
            }
            return true;
        }
        protected override void HandShakeEtc()
        {
            base.HandShakeEtc();
            if (IsAlive && sts.Get(MEMORY_STS.OPENED))
            {
                if (cmd.Get(MEMORY_CMD.READ_FIRST)) shareMotor.Write(MotorCommand.ToByteArray());
                if (shareMotor.Read() is var rm and not null) MotorState = rm.ToStructure<MotorArray>();
            }
        }
        protected override void Process()
        {
            for (int i = 0; i < C.AXES_COUNT; i++)
            {
                ref Word cmd = ref MotorCommand.MotorList[i].Control, sts = ref MotorState.MotorList[i].Control;
                if (sts.Get(MOTOR_STS.RAN_CMD)) //컨트롤러에서명령 지령을 받았을 경우에 나의 처리 방법
                {
                    if (cmd.Get(MOTOR_CMD.ENABLE) && sts.Get(MOTOR_STS.ENABLED)) cmd.Set(MOTOR_CMD.ENABLE, false);
                    if (cmd.Get(MOTOR_CMD.DISABLE) && !sts.Get(MOTOR_STS.ENABLED)) cmd.Set(MOTOR_CMD.DISABLE, false);
                    if (cmd.Get(MOTOR_CMD.ABS_MOVE) && sts.Get(MOTOR_STS.READY)) cmd.Set(MOTOR_CMD.ABS_MOVE, false);
                    if (cmd.Get(MOTOR_CMD.REL_MOVE) && sts.Get(MOTOR_STS.READY)) cmd.Set(MOTOR_CMD.REL_MOVE, false);
                    if (cmd.Get(MOTOR_CMD.JOG_P) && sts.Get(MOTOR_STS.READY)) cmd.Set(MOTOR_CMD.JOG_P, false);
                    if (cmd.Get(MOTOR_CMD.JOG_N) && sts.Get(MOTOR_STS.READY)) cmd.Set(MOTOR_CMD.JOG_N, false);
                    if (cmd.Get(MOTOR_CMD.HOME) && sts.Get(MOTOR_STS.HOMED)) cmd.Set(MOTOR_CMD.HOME, false);
                    if (cmd.Get(MOTOR_CMD.STOP) && sts.Get(MOTOR_STS.READY)) cmd.Set(MOTOR_CMD.STOP, false);
                    if (cmd.Get(MOTOR_CMD.KILL) && sts.Get(MOTOR_STS.READY)) cmd.Set(MOTOR_CMD.KILL, false);
                    if (cmd.Get(MOTOR_CMD.RESET) && !sts.Get(MOTOR_STS.ALARM)) cmd.Set(MOTOR_CMD.RESET, false);
                    if (cmd.Get(MOTOR_CMD.RUN_PROC) && sts.Get(MOTOR_STS.RAN_PROC)) cmd.Set(MOTOR_CMD.RUN_PROC, false);
                    if (cmd.Get(MOTOR_CMD.STP_PROC) && !sts.Get(MOTOR_STS.RAN_PROC)) cmd.Set(MOTOR_CMD.STP_PROC, false);
                    if (cmd.Get(MOTOR_CMD.CLR_PROC) && !sts.Get(MOTOR_STS.RAN_PROC)) cmd.Set(MOTOR_CMD.CLR_PROC, false);
                }
            }
            if (sts.Get(MEMORY_STS.RECEIVE_COMMAND))
            {
                if (cmd.Get(MEMORY_CMD.OPEN) && sts.Get(MEMORY_STS.OPENED)) cmd.Set(MEMORY_CMD.OPEN, false);
                if (cmd.Get(MEMORY_CMD.CLOSE) && !sts.Get(MEMORY_STS.OPENED)) cmd.Set(MEMORY_CMD.CLOSE, false);
            }
        }
        public Motor GetMotorState(int index) => MotorState.MotorList[index];
        public Motor[] GetMotorsState() => MotorState.MotorList;
        public Motor GetMotorCommand(int index) => MotorCommand.MotorList[index];
        public Motor[] GetMotorsCommand() => MotorCommand.MotorList;
        public void SetMotor(Motor motor) => MotorCommand.MotorList[motor.Index] = motor;
        public virtual void Enable(int index, bool isEnable)
        {
            if (isEnable) MotorCommand.MotorList[index].Control.Set(MOTOR_CMD.ENABLE, true);
            else MotorCommand.MotorList[index].Control.Set(MOTOR_CMD.DISABLE, true);
        }
        public virtual void Home(int index) => MotorCommand.MotorList[index].Control.SetOnly(MOTOR_CMD.HOME);
        public virtual void Stop(int index) => MotorCommand.MotorList[index].Control.SetOnly(MOTOR_CMD.STOP);
        public virtual void Kill(int index) => MotorCommand.MotorList[index].Control.SetOnly(MOTOR_CMD.KILL);
        public virtual void Jog(int index, bool IsForwardDirection = true)
        {
            if (IsForwardDirection) MotorCommand.MotorList[index].Control.SetOnly(MOTOR_CMD.JOG_P);
            else MotorCommand.MotorList[index].Control.SetOnly(MOTOR_CMD.JOG_N);
        }
        public virtual void Move(int index, bool isAbsolute = true)
        {
            if (isAbsolute) MotorCommand.MotorList[index].Control.SetOnly(MOTOR_CMD.ABS_MOVE);
            else MotorCommand.MotorList[index].Control.SetOnly(MOTOR_CMD.REL_MOVE);
        }
        public virtual void Reset(int index) => MotorCommand.MotorList[index].Control.SetOnly(MOTOR_CMD.RESET);
        public virtual void Clear(int index) => MotorCommand.MotorList[index].Control.Clear();
        public virtual void RunProcess(int index) => MotorCommand.MotorList[index].Control.SetOnly(MOTOR_CMD.RUN_PROC);
        public virtual void StopProcess(int index) => MotorCommand.MotorList[index].Control.SetOnly(MOTOR_CMD.STP_PROC);
        public virtual void ClearProcess(int index) => MotorCommand.MotorList[index].Control.SetOnly(MOTOR_CMD.CLR_PROC);
    }
}