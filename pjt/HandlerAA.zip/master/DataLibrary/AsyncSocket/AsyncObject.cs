﻿using System;
using System.Net.Sockets;

namespace DataLibrary.AsyncSocket
{
    //https://docs.microsoft.com/ko-kr/dotnet/framework/network-programming/asynchronous-client-socket-example
    // 비동기 작업에서 사용하는 소켓과 해당 작업에 대한 데이터 버퍼를 저장하는 클래스
    public class AsyncObject
    {
        public byte[] Buffer;
        public Socket WorkingSocket;
        public readonly int BufferSize;
        /// <summary>
        /// Variable for async socket communication
        /// </summary>
        /// <param name="bufferSize">Byte array size</param>
        public AsyncObject(int bufferSize) => Buffer = new byte[BufferSize = bufferSize];
        public void ClearBuffer() => Array.Clear(Buffer, 0, BufferSize);
    }
}
