﻿using DataLibrary.EnumDefine;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using Tool;

namespace DataLibrary.LogType
{
    public class Log
    {
        readonly string S = "|";
        public int MaxFolderSize = 1, MaxFileSize = 10; //Log folder size[Gb], file size[Mb]
        string name, filePath, folderPath;
        int fileNo;
        DateTime date;
        ReaderWriterLockSlim loc = new();
        public Log(string name, string folder = "", int maxSize = 1)
        {
            this.name = name;
            if (folder.Contains(':')) folderPath = folder;  //절대경로
            else folderPath = $@"Log\{folder}";    //상대경로
            MaxFolderSize = maxSize;
            CheckFolder();
            CheckFile();
        }
        public string Info(string message, bool isUseDebug = true) { Write(LOG_STATE.INFO, message, isUseDebug); return message; }
        public void Warning(string message, bool isUseDebug = true) => Write(LOG_STATE.WARNING, message, isUseDebug);
        public void Error(string message, bool isUseDebug = true) => Write(LOG_STATE.ERROR, message, isUseDebug);
        public void Write(LOG_STATE state, string message, bool isUseDebug = true)
        {
            CheckFile();
            string msg = $"{DateTime.Now:HH:mm:ss fff}{S}{state.Str()}{S}{message}";
            if (isUseDebug) Debug.WriteLine(msg);
            try
            {
                loc.EnterWriteLock();
                File.AppendAllText(filePath, msg + Environment.NewLine);
                //File.AppendAllTextAsync(filePath, msg + Environment.NewLine);
                loc.ExitWriteLock();
            }
            catch { }
        }
        #region Function
        void CheckFolder()
        {
            if (Directory.Exists(folderPath)) return;
            Directory.CreateDirectory(folderPath);
        }
        void CheckFile()
        {
            if (date != DateTime.Today)
            {
                fileNo = 0; //날짜변경시 File의 번호 초기화
                date = DateTime.Today;
                var fileArray = new DirectoryInfo(folderPath).GetFileSystemInfos();
                long totalSize = 0;
                foreach (var v in fileArray) if (v is FileInfo f and not null) totalSize += f.Length;
                long delSize = 0;
                long logSize = (long)(MaxFolderSize * Math.Pow(1024, 3));    //Byte
                foreach (var v in fileArray.OrderBy(x => x.LastWriteTime))
                {
                    if (totalSize - delSize <= logSize) break;
                    if (v is not FileInfo f) continue;
                    delSize += f.Length;
                    File.Delete(f.FullName); //날짜가 바뀔 때마다 용량큰 파일 삭제
                }
            }
            while (true)
            {
                filePath = $@"{folderPath}\{name}_{DateTime.Now:yyyy-MM-dd}_{fileNo}.log";
                if (File.Exists(filePath))
                    if (new FileInfo(filePath).Length > MaxFileSize * 1024 * 1024) fileNo++;    //파일용량초과시 이름변경
                    else break;
                else { using var sw = File.CreateText(filePath); break; }
            }
        }
        #endregion
    }
}