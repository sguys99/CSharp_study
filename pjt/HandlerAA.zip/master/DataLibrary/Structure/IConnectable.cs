﻿using System;

namespace DataLibrary.Structure
{
    public interface IConnectable : IDisposable
    {
        void Open();
        void Close();
        bool GetOpen();
    }
}
