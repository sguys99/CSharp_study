﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace DataLibrary.Structure.Vision
{
    [Serializable]
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct Lens
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 100)]
        public byte[] Name;
        public double Magnification;
        public double Calibration;
        public double Rotation;
        [MarshalAs(UnmanagedType.I1)]
        public bool IsFlip;
        public static Lens Create(string name = "MV-CA050-10GM", double magnification = 2, double calibration = 1, double rotation = 0, bool isFlip = false)
        {
            Lens lens = new();
            lens.Name = new byte[100];
            byte[] ba = Encoding.GetEncoding("UTF-8").GetBytes(name);
            Array.Copy(ba, lens.Name, ba.Length);
            lens.Magnification = magnification;
            lens.Calibration = calibration;
            lens.Rotation = rotation;
            lens.IsFlip = isFlip;
            return lens;
        }
    }
}