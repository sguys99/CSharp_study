﻿namespace DataLibrary.Structure
{
    public interface Loggable { event SendVariableEventHandler<string> LogLog; }
}
