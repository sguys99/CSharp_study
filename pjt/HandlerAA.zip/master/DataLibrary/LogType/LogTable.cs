﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Tool;

namespace DataLibrary.LogType
{
    public class LogTable
    {
        string folderPath, fileName, filePath;
        int maxFileSize, maxFolderSize, fileNo;
        string[] MonitorColumnsTitle = { "1", "2" };
        string[] columnsTitle = new string[] { "Date", "Category", "Item", "Detail" };
        DateTime date;
        public LogTable(string folderPath, string fileName, int maxFileSize = 10, int maxFolderSize = 1)
        {
            this.folderPath = folderPath;
            this.fileName = fileName;
            this.maxFileSize = maxFileSize;
            this.maxFolderSize = maxFolderSize;
            if (!Directory.Exists(folderPath)) Directory.CreateDirectory(folderPath);
        }
        public void SetMonitorColumnsTitle(params string[] strs) => MonitorColumnsTitle = strs;
        void CheckFile(bool isCreateColumnTitle)
        {
            if (date != DateTime.Today)
            {
                fileNo = 0; //날짜변경시 File의 번호 초기화
                date = DateTime.Today;
                var fileArray = new DirectoryInfo(folderPath).GetFileSystemInfos();
                long totalSize = 0;
                foreach (var v in fileArray) if (v is FileInfo f and not null) totalSize += f.Length;
                long delSize = 0;
                long logSize = (long)(maxFolderSize * Math.Pow(1024, 3));    //Byte
                foreach (var v in fileArray.OrderBy(x => x.LastWriteTime))
                {
                    if (totalSize - delSize <= logSize) break;
                    if (v is not FileInfo f) continue;
                    delSize += f.Length;
                    File.Delete(f.FullName); //날짜가 바뀔 때마다 용량큰 파일 삭제
                }
            }
            while (true)
            {
                filePath = $@"{folderPath}{fileName}_{DateTime.Now:yyyy-MM-dd}_{fileNo}.csv";
                if (!File.Exists(filePath)) break;
                else if (new FileInfo(filePath).Length > maxFileSize * 1024 * 1024) fileNo++;
                else break;
                //{
                //    if (new FileInfo(filePath).Length > maxFileSize * 1024 * 1024) fileNo++;
                //}
                //else break;
                //    if (new FileInfo(filePath).Length > maxFileSize * 1024 * 1024) fileNo++;    //파일용량초과시 이름변경
                //    else break;
                //else break;
                //else
                //{
                //    if (isCreateColumnTitle) "DateTime,Category,Item,Detail".SaveCSV(filePath);
                //    else string.Join(',',MonitorColumnsTitle).SaveCSV(filePath);
                //    break;
                //}
            }
        }
        public void Write(string category, string item = "", string detail = "") => Write(new(category, item, detail));
        public void Write(LogItem item)
        {
            CheckFile(true);
            $"{item.Date:HH:mm:ss fff},{item.Category},{item.Item},{item.Detail}".SaveCSV(filePath, columnsTitle);
        }
        public List<LogItem> Read(DateTime startDate, DateTime endDate)
        {
            List<LogItem> contents = new();
            if (!Directory.Exists(folderPath)) return contents;
            if (startDate > endDate) return contents;
            DateTime nowDate = startDate;
            while (true)
            {
                if (nowDate > endDate) break;
                var fileNo = 0;
                while (true)
                {
                    var filePath = $@"{folderPath}{fileName}_{nowDate:yyyy-MM-dd}_{fileNo}.csv";
                    if (!File.Exists(filePath)) break;
                    foreach (var v in filePath.LoadCSV())
                    {
                        if (v[0].Contains("DateTime")) continue;
                        if (v.Length != 4) continue;
                        contents.Add(new(nowDate, v));
                    }
                    fileNo++;
                }
                nowDate += new TimeSpan(1, 0, 0, 0);
            }
            List<LogItem> logList = new();
            foreach (var item in contents)
                if (item.Date >= startDate && item.Date < endDate)
                    logList.Add(item);
            return logList;
        }
        public void AllocateColumnTitle(params string[] strs) => columnsTitle = strs;
        public void WriteMonitor(params string[] strs)
        {
            CheckFile(false);
            List<string> list = new() { $"{DateTime.Now:HH:mm:ss fff}" };
            list.AddRange(from v in strs select v);
            string.Join(',', list).SaveCSV(filePath, columnsTitle);
        }
        public List<string[]> ReadMonitor(DateTime startDate, DateTime endDate)
        {
            List<string[]> contents = new();
            //1열이 DateTime, 1행이 Column Title 인 리스트를 호출해야 함

            return contents;
        }
    }
}