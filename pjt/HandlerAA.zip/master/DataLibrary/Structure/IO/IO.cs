﻿using DataLibrary.EnumDefine;
using DataLibrary.UserType;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Tool;

namespace DataLibrary.Structure.IO
{
    public class IO : Memory, IExchangable
    {
        public virtual event SendVariableEventHandler<string> OccurAlarm;
        protected int[] diArray, doArray, aiArray, aoArray;
        protected Share shareDI, shareDO, shareAI, shareAO;
        protected string diName = "_DI", doName = "_DO", aiName = "_AI", aoName = "_AO";

        /// <summary>
        /// Memory Class 상속. IExchangable 구현
        /// </summary>
        /// <param name="deviceName">Device이름 입력. 예: "ACS"</param>
        /// <param name="isUI">UI 여부 기입</param>
        /// <param name="diSize">Int Size</param>
        /// <param name="doSize">Int Size</param>
        /// <param name="aiSize">Int Size</param>
        /// <param name="aoSize">Int Size</param>
        public IO(string deviceName, bool isUI = true, int diSize = 1, int doSize = 1, int aiSize = 8, int aoSize = 8) : base(deviceName, isUI)
        {
            diArray = new int[diSize];
            doArray = new int[doSize];
            aiArray = new int[aiSize];
            aoArray = new int[aoSize];
            ConstructShare(isUI, ref shareDI, diName, diSize);
            ConstructShare(isUI, ref shareDO, doName, doSize);
            ConstructShare(isUI, ref shareAI, aiName, aiSize);
            ConstructShare(isUI, ref shareAO, aoName, aoSize);
        }
        void ConstructShare(bool isUI, ref Share share, string subName, int intSize)
        {
            if (isUI) share = new(SourceName, DestinationName + subName, intSize * C.INTBYTE);
            else share = new(SourceName + subName, DestinationName, intSize * C.INTBYTE);
        }
        protected override bool ReadFirst()
        {
            if (shareDO.Read() is var rd and not null) Buffer.BlockCopy(rd, 0, doArray, 0, rd.Length);
            if (shareAO.Read() is var ra and not null) Buffer.BlockCopy(ra, 0, aoArray, 0, ra.Length);
            cmd.Set(MEMORY_CMD.READ_FIRST, true);
            return true;
        }
        protected override void HandShakeEtc()
        {
            if (IsAlive && sts.Get(MEMORY_STS.OPENED))
            {
                if (cmd.Get(MEMORY_CMD.READ_FIRST)) { shareDO.Write(doArray.ToByteArray()); shareAO.Write(aoArray.ToByteArray()); }
                if (shareDI.Read() is var rd and not null) Buffer.BlockCopy(rd, 0, diArray, 0, rd.Length);
                if (shareAI.Read() is var ra and not null) Buffer.BlockCopy(ra, 0, aiArray, 0, ra.Length);
            }
        }
        public bool GetDI(int i) => ((diArray[i / C.INTBIT] >> (i % C.INTBIT)) & 1) == 1;
        public bool GetDO(int i) => ((doArray[i / C.INTBIT] >> (i % C.INTBIT)) & 1) == 1;
        public int GetAI(int i) => aiArray[i];
        public int GetAO(int i) => aoArray[i];
        public List<bool> GetDI() => new BitArray(diArray).Cast<bool>().ToList();
        public List<bool> GetDO() => new BitArray(doArray).Cast<bool>().ToList();
        public List<int> GetAI() => new(aiArray);
        public List<int> GetAO() => new(aoArray);
        public void SetDO(int i, bool v) => doArray[i / C.INTBIT] = ((Word)doArray[i / C.INTBIT]).Set(i, v);
        public void SetAO(int i, int v) => aoArray[i] = v;
    }
}