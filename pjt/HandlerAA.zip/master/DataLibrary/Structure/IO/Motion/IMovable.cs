﻿namespace DataLibrary.Structure.IO.Motion
{
    public interface IMovable
    {
        Motor GetMotorState(int index);
        Motor[] GetMotorsState();
        Motor GetMotorCommand(int index);
        Motor[] GetMotorsCommand();
        void SetMotor(Motor motor);
        void Enable(int index, bool isEnable);
        void Home(int index);
        void Stop(int index);
        void Kill(int index);
        void Jog(int index, bool IsForwardDirection = true);
        void Move(int index, bool isAbsolute = true);
        void Reset(int index);
        void Clear(int index);
        void RunProcess(int index);
        void StopProcess(int index);
        void ClearProcess(int index);
    }
}
