﻿//written by im.kim on '22.01.13
using System;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Media;

namespace Tool
{
    public static class Etc
    {
        public static DateTime GetBuildTime() => File.GetLastWriteTime(Assembly.GetExecutingAssembly().Location);
        public static DependencyObject FindControl(DependencyObject parent, string name)
        {   // Find a descendant control by name.// See if this object has the target name.
            if ((parent is FrameworkElement element) && (element.Name == name)) return parent;
            int num_children = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < num_children; i++)// Recursively check the children.
            { // See if this child has the target name.
                var descendant = FindControl(VisualTreeHelper.GetChild(parent, i), name);
                if (descendant != null) return descendant;
            }
            return null; // We didn't find a descendant with the target name.
        }
    }
}