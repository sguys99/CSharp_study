﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Diagnostics;
using System.IO;

namespace DataLibrary
{
    public static class SQL
    {
        public static bool CreateDB(string path)
        {
            if (!File.Exists(path))
            {
                string dirName = Path.GetDirectoryName(path);
                if (!Directory.Exists(dirName)) Directory.CreateDirectory(dirName);
                SQLiteConnection.CreateFile(path);
                return true;
            }
            return false;
        }
        public static bool RunDB(string path, string message)
        {
            if (!File.Exists(path)) return false;
            using (SQLiteConnection conn = new($"Data Source={path}"))
            {
                conn.Open();
                try { new SQLiteCommand(message, conn).ExecuteNonQuery(); }
                catch (Exception e) { Debug.WriteLine(e.ToString()); }
                conn.Close();
            }
            return true;
        }
        public static List<string> ReadDB(string path, string message, params string[] columnsTitle)
        {
            List<string> list = new();
            if (!File.Exists(path)) return list;
            using (SQLiteConnection conn = new($"Data Source={path}"))
            {
                conn.Open();
                try
                {
                    SQLiteDataReader reader = new SQLiteCommand(message, conn).ExecuteReader();
                    while (reader.Read())
                    {
                        //MessageBox.Show($"ID:{rdr["ID"]},PASS:{rdr["PASS"]},PERMIT:{rdr["PERMIT"]}");
                        List<string> subValues = new();
                        foreach (string s in columnsTitle) subValues.Add(reader[s].ToString());
                        list.Add(string.Join(',', subValues));
                    }
                    reader.Close();
                }
                catch (Exception e) { Debug.WriteLine(e.ToString()); }
                conn.Close();
            }
            return list;
        }
        public static object RunScalar(string path, string message)
        {
            object o = -1;
            if (!File.Exists(path)) return o;
            using (SQLiteConnection conn = new($"Data Source={path}"))
            {
                conn.Open();
                try
                {
                    var v = new SQLiteCommand(message, conn).ExecuteScalar();
                    o = v;
                }
                catch (Exception e) { Debug.WriteLine(e.ToString()); }
                conn.Close();
            }
            return o;
        }
    }
}