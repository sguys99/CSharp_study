﻿namespace DataLibrary.EnumDefine
{
    public enum eTX { READ, WRITE, CLEAR, }
    public enum eRX { READ, WRITE, FAIL_READ, FAIL_WRITE, CHECK_CLEAR }
    public enum RUNSTATUS { IDLE = 0, STOP = 1, RUN = 2, ERROR = 3 }
    public enum CATEGORY { CHANGE, ACTION, DETECT, }
    public enum ITEM { DOUT, AOUT, SENSOR, SET, PARAMETER, CLOSE, START, ABORT, COMPLETE, }

    public enum LOG_STATE { INFO, WARNING, ERROR, }
}
