﻿using System;
using System.Runtime.InteropServices;

namespace DataLibrary.Structure.Vision
{
    [Serializable]
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CameraAssembly
    {
        public Camera Cam;
        public Lens Lenz;
        public static CameraAssembly Create(string cameraName = "MV-CA050-10GM", string serialNumber = "02E28510182", string lensName = "MML2-HR65D", int pixelWidth = 2448, int pixelHeight = 2048, double sensorWidth = 3.45, double sensorHeight = 3.45, double magnification = 2, double calibration = 1, double rotation = 0, bool isFlip = false, bool isColor = false)
        {
            CameraAssembly camAssy = new();
            camAssy.Cam = Camera.Create(cameraName, serialNumber, pixelWidth, pixelHeight, sensorWidth, sensorHeight, isColor);
            camAssy.Lenz = Lens.Create(lensName, magnification, calibration, rotation, isFlip);
            return camAssy;
        }
    }
}