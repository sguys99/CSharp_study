//written by im.kim on '22.01.13
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace DataLibrary.UserType
{
    [Serializable]
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CustomType<C, T>   //Custom type Class
    {
        protected T _v;
        public CustomType(T v) => _v = v;
        public override string ToString() => _v.ToString();
        public static bool operator <(CustomType<C, T> a, CustomType<C, T> b) => Comparer<T>.Default.Compare(a._v, b._v) < 0;
        public static bool operator >(CustomType<C, T> a, CustomType<C, T> b) => !(a < b);
        public static bool operator <=(CustomType<C, T> a, CustomType<C, T> b) => (a < b) || (a == b);
        public static bool operator >=(CustomType<C, T> a, CustomType<C, T> b) => (a > b) || (a == b);
        public static bool operator ==(CustomType<C, T> a, CustomType<C, T> b) => a.Equals(b);
        public static bool operator !=(CustomType<C, T> a, CustomType<C, T> b) => !(a == b);
        public static C operator +(CustomType<C, T> a, CustomType<C, T> b) => (dynamic)a._v + b._v;
        public static C operator -(CustomType<C, T> a, CustomType<C, T> b) => (dynamic)a._v - b._v;
        public override bool Equals(object obj)
        {
            if (obj is null) return false; 
            if (ReferenceEquals(this, obj)) return true; 
            if (obj.GetType() != GetType()) return false;
            return EqualityComparer<T>.Default.Equals(_v, ((CustomType<C, T>)obj)._v);
        }
        public override int GetHashCode() => EqualityComparer<T>.Default.GetHashCode(_v);
    }
}
