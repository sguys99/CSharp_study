﻿namespace DataLibrary.EnumDefine
{
    public enum MEMORY_CMD { HEART, OPEN, CLOSE, READ_FIRST, }
    public enum MEMORY_STS { HEART, OPENED, READY_TO_READ, RECEIVE_COMMAND, }
}
