﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows;

namespace DataLibrary.AsyncSocket
{
    public class AsyncSocketServer : IDisposable
    {
        #region Define & Allocate Variables
        //public delegate void DeliverHandler(byte[] message);        
        public event SendVariableEventHandler<string, byte[]> Deliver;
        public event SendVariableEventHandler<string> DisconnectClient;
        string address = "127.0.0.1"; //Default IP Address
        int port = 2000;   //Default Port
        Socket server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
        List<Socket> clients = new List<Socket>();
        public bool IsStart = false;
        #endregion
        #region Major Methods
        public AsyncSocketServer(string address, int port) { this.address = address; this.port = port; }
        /// <summary>
        /// Start asynchronous socket server
        /// </summary>
        public void Start()
        {
            try
            {
                server.Bind(new IPEndPoint(IPAddress.Parse(address), port));    //Bind the listening socket to the port
                server.Listen(10);  //Start listening
                server.BeginAccept(AcceptCallback, null);   //Accept client connection
                IsStart = true;
            }
            catch (Exception e)
            {
                Debug.WriteLine($"Can't open server: {e}");
                throw;
                //MessageBox.Show($"Can't open server: {e}"); 
            }
        }
        public void Close()
        {
            clients.Clear();
            if (server.Connected) server.Shutdown(SocketShutdown.Both);
            server.Close();
            IsStart = false;
        }
        public int IsOpen() { return clients.Count; }
        /// <summary>
        /// Send Message
        /// </summary>
        /// <param name="message">Message consists of byte array</param>
        public void Send(byte[] message)
        {
            if (!server.IsBound)
            {
                MessageBox.Show("Server isn't running");
                return;
            }
            try
            {
                foreach (Socket s in clients)
                {
                    var clientIP = s.RemoteEndPoint.ToString().Split(':')[0];
                    try
                    {
                        s.Send(message);
                        //s.Send(Encoding.UTF8.GetBytes((address + '\x1' + Encoding.UTF8.GetString(message))));    //Test
                    }
                    catch (Exception e)
                    {
                        DisconnectClient?.Invoke(clientIP);
                        //MessageBox.Show($"Error send message\n{e}");
                        clients.Remove(s);
                    }
                }
            }
            catch (Exception e)
            {
                clients.Clear();
            }
        }
        public void Send(byte[] message, string ip)
        {
            if (!server.IsBound)
            {
                MessageBox.Show("Server isn't running");
                return;
            }
            try
            {
                foreach (Socket s in clients)
                {
                    var clientIP = s.RemoteEndPoint.ToString().Split(':')[0];
                    if (ip == clientIP)
                    {
                        try
                        {
                            s.Send(message);
                            //s.Send(Encoding.UTF8.GetBytes((address + '\x1' + Encoding.UTF8.GetString(message))));    //Test
                        }
                        catch (Exception e)
                        {
                            DisconnectClient?.Invoke(clientIP);
                            //MessageBox.Show($"Error send message\n{e}");
                            clients.Remove(s);
                        }
                        return;
                    }
                }
            }
            catch (Exception e)
            {
                clients.Clear();
            }
        }
        public bool RemoveClient(string ip)
        {
            foreach (Socket s in clients)
                if (ip == s.RemoteEndPoint.ToString().Split(':')[0])
                {
                    clients.Remove(s);
                    return true;
                }
            return false;
        }
        public List<string> GetClientsIP()
        {
            List<string> ips = new();
            for (int i = 0; i < clients.Count; i++)
            {
                string ip = "";
                try
                {
                    ip = clients[i].RemoteEndPoint.ToString().Split(':')[0];
                }
                catch
                {
                    Debug.WriteLine("Error GetClientsIP");
                    clients.RemoveAt(i);
                    return ips;
                }
                if (ip != "")
                {
                    ips.Add(ip);
                }
            }
            return ips;
        }
        #endregion
        #region Assist Function
        void AcceptCallback(IAsyncResult asyncResult)
        {
            try
            {
                Socket client = server.EndAccept(asyncResult);  //Accept client connection
                server.BeginAccept(AcceptCallback, null);   //Recursive wait another clients
                AsyncObject obj = new AsyncObject(4096);    //Byte array size
                obj.WorkingSocket = client; //Allocate current connected client
                                            //clients.Clear();
                clients.Add(client);    //Add current client to client list
                var clientIP = obj.WorkingSocket.RemoteEndPoint.ToString().Split(':')[0];
                Deliver?.Invoke(clientIP, Encoding.ASCII.GetBytes("Client Connected"));    //Deliver message
                client.BeginReceive(obj.Buffer, 0, 4096, 0, DataReceived, obj); //Wait message from client
            }
            catch (Exception e)
            {
                Debug.WriteLine($"{e}");
            }
        }
        void DataReceived(IAsyncResult asyncResult)
        {
            AsyncObject obj = (AsyncObject)asyncResult.AsyncState;  //Cast object to AsyncObject
            try
            {
                int received = obj.WorkingSocket.EndReceive(asyncResult);   //Number of length of received bytes
                if (received <= 0)  //If message length equals zero, close current working client
                {
                    obj.WorkingSocket.Close();
                    return;
                }
                string[] tokens = Encoding.UTF8.GetString(obj.Buffer).Split('\x0'); //Split btw ip & message      
                var clientIP = obj.WorkingSocket.RemoteEndPoint.ToString().Split(':')[0];
                Deliver?.Invoke(clientIP, Encoding.ASCII.GetBytes(tokens[0])); //Deliver message
                //Deliver.Invoke(asyncObject.Buffer); //Deliver message
                //MessageBox.Show(Encoding.UTF8.GetString(asyncObject.Buffer));   //Test Code
                obj.ClearBuffer();
            }
            catch { }
            finally
            {
                if (obj.WorkingSocket.Connected)
                    obj.WorkingSocket.BeginReceive(obj.Buffer, 0, 4096, 0, DataReceived, obj);  //Wait message from client
            }
        }
        public void Dispose() => Close();
        #endregion
    }
}
