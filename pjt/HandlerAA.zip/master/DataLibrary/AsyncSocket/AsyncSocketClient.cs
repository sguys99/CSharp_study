﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows;

namespace DataLibrary.AsyncSocket
{
    public class AsyncSocketClient : IDisposable
    {
        #region Define & Allocate Variables
        //public delegate void DeliverHandler(byte[] message);
        //public event DeliverHandler Deliver;
        public event SendVariableEventHandler<byte[]> Deliver;
        string address = "127.0.0.1"; //Default IP Address
        int port = 2000;   //Default Port
        Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
        #endregion
        #region Major Methods
        public AsyncSocketClient(string address, int port) { this.address = address; this.port = port; }
        /// <summary>
        /// Start asynchronous socket server
        /// </summary>
        public void Start()
        {
            try
            {
                client.BeginConnect(new IPEndPoint(IPAddress.Parse(address), port), ConnectCallback, client);    //Bind the listening socket to the port

            }
            catch (Exception e) { MessageBox.Show($"Can't open server: {e}"); }
        }
        public void Close()
        {
            if (client.Connected) client.Shutdown(SocketShutdown.Both);
            client.Close();
        }
        public bool IsOpen() { return client.Connected; }
        /// <summary>
        /// Send Message
        /// </summary>
        /// <param name="message">Message consists of byte array</param>
        public void Send(byte[] message)
        {
            if (!client.IsBound)
            {
                MessageBox.Show("Server isn't running");
                return;
            }
            try
            {
                client.Send(message);
            }
            catch (Exception e)
            {
            }
        }
        #endregion
        #region Assist Function
        void ConnectCallback(IAsyncResult asyncResult)
        {
            try
            {
                // Retrieve the socket from the state object.
                Socket client = (Socket)asyncResult.AsyncState;
                // Complete the connection.  
                client.EndConnect(asyncResult);
                AsyncObject obj = new AsyncObject(4096);    //Byte array size
                obj.WorkingSocket = client; //Allocate current connected client
                client.BeginReceive(obj.Buffer, 0, 4096, 0, DataReceived, obj); //Wait message from client
                Console.WriteLine($"Socket connected to {client.RemoteEndPoint}");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
        void DataReceived(IAsyncResult asyncResult)
        {
            AsyncObject asyncObject = (AsyncObject)asyncResult.AsyncState;  //Cast object to AsyncObject
            try
            {
                int received = asyncObject.WorkingSocket.EndReceive(asyncResult);   //Number of length of received bytes
                if (received <= 0)  //If message length equals zero, close current working client
                {
                    asyncObject.WorkingSocket.Close();
                    return;
                }
                string[] tokens = Encoding.UTF8.GetString(asyncObject.Buffer).Split('\x0'); //Split btw ip & message       
                Deliver?.Invoke(Encoding.ASCII.GetBytes(tokens[0])); //Deliver message
                //Deliver.Invoke(asyncObject.Buffer); //Deliver message
                //MessageBox.Show(Encoding.UTF8.GetString(asyncObject.Buffer));   //Test Code
                asyncObject.ClearBuffer();
            }
            catch (Exception e)
            {
            }
            finally
            {
                if (asyncObject.WorkingSocket.Connected)
                    asyncObject.WorkingSocket.BeginReceive(asyncObject.Buffer, 0, 4096, 0, DataReceived, asyncObject);  //Wait message from client
            }
        }
        public void Dispose() => Close();
        #endregion
    }
}
