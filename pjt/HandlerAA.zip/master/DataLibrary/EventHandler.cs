﻿namespace DataLibrary
{
    public delegate void FlagEventHandler();
    public delegate void SendVariableEventHandler<T>(T t);
    public delegate void SendVariableEventHandler<T, U>(T t, U u);
    public delegate void SendVariableEventHandler<T, U, V>(T t, U u, V v);
    public delegate void SendVariableEventHandler<T, U, V, W>(T t, U u, V v, W w);
    public delegate T ReceiveVariableEventHandler<T>();
    public delegate U HandShakeVariablesEventHandler<T, U>(T t);
}
