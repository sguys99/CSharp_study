﻿using System.Collections.Generic;
using System.Windows.Controls;

namespace UILibrary.UI
{
    public interface IStructurableControl
    {
        public uint Level { get; set; }
        public IStructurableControl ParentNode { get; set; }
        public List<IStructurableControl> ChildNodes { get; set; }
        public string ButtonName { get; set; }
        public UserControl EditControl { get; set; }
    }
}